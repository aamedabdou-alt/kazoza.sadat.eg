@echo off
net session >nul 2>&1 || (echo شغّل الملف ده بزر الماوس اليمين: Run as administrator & pause & exit /b)
netsh advfirewall firewall add rule name="Factory Server" dir=in action=allow protocol=TCP localport=3000 profile=private,domain
echo تم. الأجهزة على نفس الواي فاي تقدر تدخل.
pause
