#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""سيرفر إدارة المصنع (كازوزا وبيبسي) — بايثون، مكتبات أساسية فقط.
التشغيل:  python server.py      (المنفذ الافتراضي 3000، ويمكن تغييره بمتغير PORT)
"""
import copy, getpass, hashlib, hmac, json, os, secrets, shutil, socket, sys, threading, time
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__))
DATA, BK, PD = (os.path.join(BASE, n) for n in ('data.json', 'backups', 'proofs'))
PORT = int(os.environ.get('PORT', '3000'))
LOCK = threading.RLock()
COLL = ['products', 'materials', 'customers', 'suppliers', 'employees', 'methods', 'recipes',
        'users', 'tx', 'prices', 'reps', 'closes', 'log']
ROLES = ('admin', 'acc', 'work')
PROOF_METHODS = ('فودافون كاش', 'إنستاباي', 'شيك')
DENY = 'مش مسموح لك بالتعديل ده'


# ---------------------------------------------------------------- passwords
def hash_pw(p, salt=None):
    salt = salt or secrets.token_hex(8)
    h = hashlib.scrypt(str(p).encode('utf-8'), salt=salt.encode('utf-8'), n=16384, r=8, p=1, dklen=32)
    return salt + ':' + h.hex()          # نفس صيغة نسخة Node، فملف data.json متوافق مع الاتنين


def chk(p, h):
    try:
        return hmac.compare_digest(hash_pw(p, h.split(':')[0]), h)
    except Exception:
        return False


# ---------------------------------------------------------------- state
def fresh():
    names = ['نقدي', 'فودافون كاش', 'إنستاباي', 'تحويل بنكي', 'شيك']
    return {
        'set': {'name': 'مصنع الكازوزا والبيبسي', 'cur': 'ج.م', 'invNo': 0},
        'products': [{'id': 1, 'name': 'كازوزا', 'price': 0, 'cost': 0, 'stock': 0},
                     {'id': 2, 'name': 'بيبسي', 'price': 0, 'cost': 0, 'stock': 0}],
        'materials': [], 'customers': [], 'suppliers': [], 'employees': [],
        'methods': [{'id': i + 3, 'name': n, 'proof': 1 if n in PROOF_METHODS else 0} for i, n in enumerate(names)],
        'tx': [], 'recipes': [], 'prices': [], 'reps': [], 'closes': [], 'log': [],
        'users': [],
        'ver': 1}


def normalize(st):
    for k in COLL:
        if not isinstance(st.get(k), list):
            st[k] = []
    if not isinstance(st.get('set'), dict):
        st['set'] = {'name': 'مصنع', 'cur': 'ج.م'}
    st['set']['invNo'] = st['set'].get('invNo') or 0
    st['ver'] = st.get('ver') or 1
    return st


def make_admin():
    """إنشاء حساب المدير في أول تشغيل (لا توجد كلمة مرور مكتوبة في الكود).
    يقرأ من متغيرات البيئة FACTORY_ADMIN_USER / FACTORY_ADMIN_PASS / FACTORY_ADMIN_NAME،
    وإلا يسأل في الشاشة، وإلا (تشغيل بدون شاشة) يولّد كلمة مرور عشوائية ويطبعها مرة واحدة."""
    user, pw = os.environ.get('FACTORY_ADMIN_USER'), os.environ.get('FACTORY_ADMIN_PASS')
    name = os.environ.get('FACTORY_ADMIN_NAME') or 'المدير'
    if not (user and pw):
        if sys.stdin and sys.stdin.isatty():
            print('\n=== أول تشغيل: إنشاء حساب المدير ===')
            name = input('الاسم الظاهر في الترحيب (مثال: محمد أحمد) [المدير]: ').strip() or 'المدير'
            while not user:
                user = input('اسم المستخدم (حروف إنجليزية بدون مسافات): ').strip()
            while True:
                pw = getpass.getpass('كلمة المرور (6 أحرف على الأقل): ')
                if len(pw) >= 6 and pw == getpass.getpass('أعد كتابة كلمة المرور للتأكيد: '):
                    break
                print('كلمة المرور قصيرة أو غير متطابقة، حاول مرة أخرى.')
        else:
            user, pw = 'admin', secrets.token_urlsafe(9)
            print('تم إنشاء حساب المدير:  اسم المستخدم admin  وكلمة المرور %s   (غيّرها بعد الدخول)' % pw)
    return {'id': 8, 'name': name, 'user': user, 'pass': hash_pw(pw), 'role': 'admin'}


try:
    with open(DATA, encoding='utf-8') as f:
        S = normalize(json.load(f))
except Exception:
    S = fresh()
os.makedirs(PD, exist_ok=True)


def persist():
    tmp = DATA + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(S, f, ensure_ascii=False)
    os.replace(tmp, DATA)


def backup():
    try:
        os.makedirs(BK, exist_ok=True)
        dst = os.path.join(BK, 'data-%s.json' % date.today().isoformat())
        if os.path.exists(DATA) and not os.path.exists(dst):
            shutil.copyfile(DATA, dst)
        for n in sorted(os.listdir(BK))[:-30]:
            os.remove(os.path.join(BK, n))
    except Exception:
        pass


def backup_loop():
    while True:
        time.sleep(3600)
        with LOCK:
            backup()


def pub():
    d = dict(S)
    d['users'] = [{k: v for k, v in u.items() if k != 'pass'} for u in S['users']]
    return d


def proof_path(i):
    return os.path.join(PD, ''.join(c for c in str(i) if c.isdigit()) + '.txt')


# ---------------------------------------------------------------- operations (نفس منطق المتصفح)
def apply_ops(st, o):
    for k, items in o['add'].items():
        for x in items:
            if not any(y.get('id') == x.get('id') for y in st[k]):
                st[k].append(x)
    for k, items in o['upd'].items():
        for u in items:
            t = next((y for y in st[k] if y.get('id') == u.get('id')), None)
            if t is None:
                continue
            for f, v in u.items():
                if f == 'id':
                    continue
                if f == '$d':
                    for g, dv in v.items():
                        t[g] = (t.get(g) or 0) + dv
                else:
                    t[f] = v
    for k, ids in o['del'].items():
        st[k] = [y for y in st[k] if y.get('id') not in ids]
    if o.get('set'):
        st['set'] = o['set']


def is_empty(o):
    return not any(o[k][c] for k in ('add', 'upd', 'del') for c in o[k]) and not o.get('set')


def authz(u, o, pw):
    touched = {c for k in ('add', 'upd', 'del') for c, v in o[k].items() if v}
    if u['role'] == 'admin':
        if any(o['del'].get(k) for k in ('users', 'employees')):
            me = next(x for x in S['users'] if x['id'] == u['id'])
            if not pw or not chk(pw, me['pass']):
                return 'كلمة المرور غير صحيحة'
        return None
    if o.get('set') or 'users' in touched:
        return DENY
    if o['del'].get('employees'):
        return 'حذف الموظفين للمدير فقط'
    if u['role'] == 'acc':
        return None
    if touched - {'tx', 'customers', 'products', 'materials', 'log'} or any(k != 'log' and v for k, v in o['del'].items()):
        return DENY
    if o['upd'].get('log'):
        return DENY
    if any(x.get('type') not in ('sale', 'production', 'collect') for x in o['add'].get('tx', [])):
        return DENY
    for k in ('products', 'materials'):
        if any(set(x) - {'id', '$d'} for x in o['upd'].get(k, [])):
            return DENY
    return None


def do_sync(u, b):
    global S
    ops = b.get('ops') or {}
    o = {k: (ops.get(k) or {}) for k in ('add', 'upd', 'del')}
    if isinstance(ops.get('set'), dict):
        o['set'] = ops['set']
    for k in ('add', 'upd', 'del'):
        if not isinstance(o[k], dict):
            return 400, {'err': 'طلب غير صالح'}
        for c, v in o[k].items():
            if c not in COLL or not isinstance(v, list):
                return 400, {'err': 'طلب غير صالح'}
            if k != 'del' and not all(isinstance(x, dict) and 'id' in x for x in v):
                return 400, {'err': 'طلب غير صالح'}
    err = authz(u, o, b.get('pw'))
    if err:
        return 403, {'err': err}
    for x in o['add'].get('users', []):
        x['pass'] = hash_pw(x.get('pass') or '')
        if x.get('role') not in ROLES:
            x['role'] = 'work'
        if any(str(y['user']).lower() == str(x.get('user')).lower() for y in S['users']):
            x['user'] = '%s_%s' % (x.get('user'), x['id'])
    for x in o['upd'].get('users', []):
        if 'pass' in x:
            x['pass'] = hash_pw(x['pass'])
        if 'role' in x and x['role'] not in ROLES:
            del x['role']
    N = copy.deepcopy(S)
    for x in o['add'].get('tx', []):
        if x.get('type') == 'sale':
            N['set']['invNo'] += 1
            x['no'] = N['set']['invNo']
    if o.get('set'):
        o['set'] = {**o['set'], 'invNo': N['set']['invNo']}
    try:
        apply_ops(N, o)
    except Exception:
        return 400, {'err': 'طلب غير صالح'}
    if not any(x.get('role') == 'admin' for x in N['users']) or u['id'] in o['del'].get('users', []):
        return 400, {'err': 'لازم يفضل مدير واحد على الأقل ومينفعش تحذف نفسك'}
    if not is_empty(o):
        N['ver'] = S['ver'] + 1
        S = N
        persist()
    return 200, {'state': pub(), 'ver': S['ver']}


TOKENS = {}


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def send(self, code, obj=None, raw=None, ctype='application/json; charset=utf-8'):
        body = raw if raw is not None else json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self.route('GET')

    def do_POST(self):
        self.route('POST')

    def route(self, method):
        url = urlparse(self.path)
        p = url.path
        n = int(self.headers.get('Content-Length') or 0)
        raw_body = self.rfile.read(n) if n else b''
        if method == 'GET' and not p.startswith('/api/'):
            for d in (BASE, os.path.join(BASE, 'public')):
                f = os.path.join(d, 'index.html')
                if os.path.exists(f) and p in ('/', '/index.html'):
                    with open(f, 'rb') as fh:
                        return self.send(200, raw=fh.read(), ctype='text/html; charset=utf-8')
            return self.send(204 if p == '/favicon.ico' else 404, {'err': 'not found'})
        if n > 30_000_000:
            return self.send(413, {'err': 'too large'})
        try:
            b = json.loads(raw_body) if raw_body else {}
            if not isinstance(b, dict):
                raise ValueError
        except Exception:
            return self.send(400, {'err': 'bad json'})
        if p == '/api/login':
            return self.login(b)
        tok = self.headers.get('x-tok')
        with LOCK:
            uid = TOKENS.get(tok)
            u = next((x for x in S['users'] if x['id'] == uid), None)
            if not u:
                return self.send(401, {'err': 'سجّل الدخول من جديد'})
            return self.api(p, b, u, tok, url)

    def login(self, b):
        with LOCK:
            name = str(b.get('u') or '').strip().lower()
            u = next((x for x in S['users'] if str(x['user']).lower() == name), None)
            ok = bool(u) and chk(b.get('p') or '', u['pass'])
        if not ok:
            time.sleep(0.4)
            return self.send(401, {'err': 'بيانات الدخول غير صحيحة'})
        t = secrets.token_hex(24)
        with LOCK:
            TOKENS[t] = u['id']
        return self.send(200, {'token': t, 'me': {k: u[k] for k in ('id', 'name', 'user', 'role')}})

    def api(self, p, b, u, tok, url):
        global S
        me = {k: u[k] for k in ('id', 'name', 'user', 'role')}
        if p == '/api/me':
            return self.send(200, {'me': me, 'state': pub(), 'ver': S['ver']})
        if p == '/api/state':
            v = (parse_qs(url.query).get('ver') or ['0'])[0]
            return self.send(200, {'same': 1} if v == str(S['ver']) else {'state': pub(), 'ver': S['ver']})
        if p == '/api/logout':
            TOKENS.pop(tok, None)
            return self.send(200, {})
        if p == '/api/sync':
            code, j = do_sync(u, b)
            return self.send(code, j)
        if p == '/api/proof' and self.command == 'POST':
            i = ''.join(c for c in str(b.get('id') or '') if c.isdigit())
            d = b.get('data')
            if not i or not isinstance(d, str) or not d.startswith('data:image/') or len(d) > 6_000_000:
                return self.send(400, {'err': 'صورة غير صالحة'})
            with open(proof_path(i), 'w', encoding='utf-8') as f:
                f.write(d)
            return self.send(200, {'ok': 1})
        if p == '/api/proof':
            try:
                with open(proof_path((parse_qs(url.query).get('id') or [''])[0]), encoding='utf-8') as f:
                    return self.send(200, {'data': f.read()})
            except Exception:
                return self.send(404, {'err': 'no image'})
        if p == '/api/proofdel':
            if u['role'] == 'work':
                return self.send(403, {'err': 'مش مسموح'})
            try:
                os.remove(proof_path(b.get('id')))
            except Exception:
                pass
            return self.send(200, {'ok': 1})
        if p == '/api/password':
            if u['role'] != 'admin':
                return self.send(403, {'err': 'للمدير فقط'})
            if str(b.get('u') or '').strip().lower() != str(u['user']).lower() or not chk(b.get('o') or '', u['pass']):
                time.sleep(0.4)
                return self.send(403, {'err': 'اسم المستخدم أو كلمة المرور الحالية غير صحيحة'})
            nw = str(b.get('n') or '')
            if len(nw) < 6 or nw == b.get('o'):
                return self.send(400, {'err': 'كلمة المرور الجديدة غير صالحة'})
            u['pass'] = hash_pw(nw)
            S['ver'] += 1
            persist()
            return self.send(200, {'ok': 1})
        if u['role'] != 'admin':
            return self.send(403, {'err': 'للمدير فقط'})
        if p == '/api/import':
            d = b.get('state')
            if not isinstance(d, dict) or not isinstance(d.get('tx'), list) or not isinstance(d.get('products'), list):
                return self.send(400, {'err': 'ملف غير صالح'})
            N = {**fresh(), **d, 'users': S['users'], 'ver': S['ver'] + 1}
            N.pop('seq', None)
            N.pop('uv', None)
            normalize(N)
            N['set'] = {**N['set'], 'invNo': max(S['set'].get('invNo') or 0, (d.get('set') or {}).get('invNo') or 0)}
            S = N
            persist()
            return self.send(200, {'state': pub(), 'ver': S['ver']})
        if p == '/api/reset':
            if not chk(b.get('pw') or '', u['pass']):
                return self.send(403, {'err': 'كلمة المرور غير صحيحة'})
            S = {**fresh(), 'users': S['users'], 'ver': S['ver'] + 1}
            S['set']['invNo'] = 0
            persist()
            return self.send(200, {'state': pub(), 'ver': S['ver']})
        return self.send(404, {'err': 'not found'})


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        pass


def lan_ips():
    ips = []
    for target in ('10.255.255.255', '192.168.255.255', '8.8.8.8'):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((target, 1))
            ips.append(s.getsockname()[0])
            s.close()
        except Exception:
            pass
    try:
        ips += [i[4][0] for i in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)]
    except Exception:
        pass
    return [i for i in dict.fromkeys(ips) if not i.startswith('127.') and not i.startswith('169.254.')]


if __name__ == '__main__':
    with LOCK:
        if not S['users']:
            S['users'] = [make_admin()]
        persist()
        backup()
    threading.Thread(target=backup_loop, daemon=True).start()
    try:
        srv = Server(('0.0.0.0', PORT), Handler)
    except OSError:
        print('المنفذ %d مشغول — يمكن أن يكون السيرفر شغالاً بالفعل في نافذة أخرى.' % PORT)
        sys.exit(1)
    print('\n=== سيرفر المصنع شغال (Python) ===')
    print('على الكمبيوتر ده:  http://localhost:%d' % PORT)
    for ip in lan_ips():
        print('من الموبايلات والأجهزة التانية:  http://%s:%d' % (ip, PORT))
    print('\nما تقفلش الشاشة السودا دي طول ما الناس بتشتغل.\n')
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
