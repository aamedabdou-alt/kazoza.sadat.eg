@echo off
chcp 65001 >nul
title Factory Server (Python)
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python is not installed.
    echo Download it from https://www.python.org/downloads/ and tick "Add Python to PATH" during setup.
  ) else (
    python server.py
  )
)
pause
